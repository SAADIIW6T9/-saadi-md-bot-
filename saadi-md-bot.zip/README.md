# SAADI-MD-BOT

WhatsApp Multi-Device Bot deployed on Render/Railway.

## Deploy
1. Upload files to GitHub
2. Connect repo to Render/Railway
3. Set environment variables (if needed)
4. Deploy and scan QR code from logs